
/*
 * Ver 1.0  4 July 2016
*/ 

#include <pebble.h>
#include "common.h"

#ifdef PBL_PLATFORM_CHALK
#define H_CHAR_START_POS 21
#else
#define H_CHAR_START_POS 1
#endif
#define H_CHAR_LENGHTH 9
#define H_NBR_OF_CHARS 15
#define V_CHAR_START_POS 28
#define V_CHAR_HEIGHT 20
#define V_NBR_OF_CHARS 5	
#ifdef PBL_PLATFORM_CHALK
#define H_CURSOR_START_POS 21  
#else
#define H_CURSOR_START_POS 1  
#endif
#define V_CURSOR_START_POS 48
#define H_CURSOR_LENGTH 7
#define CURSOR_DELAY 75
#define MINIMUM_CURSOR_DELAY 30  				// See window_single_repeating_click_subscribe()
#define MAXIMUM_CURSOR_DELAY 999
	
#define NBR_OF_TEXT_LAYERS 6
#define MONO_FONT RESOURCE_ID_FONT_UBUNTUMONO_B_18	// we need a non proportional font
	
#define TEXT_ATOZ0 "abcdefghi jklmn"		// put space in the middle of the 26 letters
#define TEXT_ATOZ1 "opqrstuvwxyz,!?"
#define TEXT_ATOZ2 "0123456789+-*/@"
#define TEXT_ATOZ3 "ABCDEFGHI JKLMN"
#define TEXT_ATOZ4 "OPQRSTUVWXYZ()$"
	
#define TEXT_M_NUMBER    " Text Number = "
	
#define TEXT_EMPTY       "               "
	
#define TEXT_LIGHTON     "Backlight = ON "
#define TEXT_LIGHTOFF    "Backlight = OFF"

#define TEXT_TIMESX      " Show    Times "
#define TEXT_TIMES1      " Show Once     "
#define TEXT_FOREVER     " Show Forever  "
	
#ifdef PBL_PLATFORM_APLITE
#define TEXT_COLORW      " Text = WHITE  "
#define TEXT_COLORB      " Text = BLACK  "
#else
#define TEXT_COLORW      " Text = YELLOW "
#define TEXT_COLORB      " Text = RED    "
#endif
	
#define TEXT_SCROLL_LEFT "  Scroll LEFT  "
#define TEXT_SCROLL_UP	 "  Scroll UP    "
	
#define TEXT_CURSOR1     " Cursor Delay  "
#define TEXT_CURSOR2     " in Millisec.  "
	
#define TEXT_RESTORE_1	 "Reset My_Texts "
#define TEXT_RESTORE_2	 "  to Original  "
#define TEXT_RESTORE_NO	 "      NO       "
#define TEXT_RESTORE_YES "      YES      "
	
		
static Window *input_window;
static TextLayer* text_layers[NBR_OF_TEXT_LAYERS];
static Layer *root_layer;
static Layer *cursor_layer;	
static GFont mono_font;

static char text_buffers[NBR_OF_TEXT_LAYERS][H_NBR_OF_CHARS + 1];

static int16_t h_start;
static int16_t v_start;
static bool h_direction;
static bool v_direction;
static int16_t message_number = 1;
static int screen_mode;
static int cursor_delay;

void show_input_window(int index)
{
	screen_mode = index;
	window_stack_push(input_window, false);
}

static void clear_all_texts()
{
	int i;
	
	for (i = 0; i < NBR_OF_TEXT_LAYERS; ++i)
		strcpy(text_buffers[i], "               ");
}

static void show_texts()
{
	int i;
	
	for (i = 0; i < NBR_OF_TEXT_LAYERS; ++i)
		text_layer_set_text(text_layers[i], text_buffers[i]);
}


static void input_window_load(Window *input_window)
{
//APP_LOG(APP_LOG_LEVEL_DEBUG, "text_mode: %d", text_mode);
	
	clear_all_texts();
	if (text_mode == SHOW_NEW_MESSAGE)
	{	
		strcpy(text_buffers[1], TEXT_M_NUMBER);
		h_start = H_CURSOR_START_POS;
		v_start = V_CURSOR_START_POS + (V_CHAR_HEIGHT * 3);	// Start at Capital A
		h_direction = true;
		v_direction = true;
		int_to_string(message_number, &text_buffers[2][7]);
	}
	
	if (text_mode == RESTORE_TEXTS)
	{	
		strcpy(text_buffers[1], TEXT_RESTORE_1);
		strcpy(text_buffers[2], TEXT_RESTORE_2);
		strcpy(text_buffers[3], TEXT_RESTORE_NO);
		restore_yes = false;
	}

	if (text_mode == SHOW_SETTINGS)
	{	
		switch (screen_mode)
		{
			case 0:
				if (back_light == true)
					strcpy(text_buffers[1], TEXT_LIGHTON);
				else
					strcpy(text_buffers[1], TEXT_LIGHTOFF);
				break;
		
			case 1:
				if (text_repeat == FOREVER)
					strcpy(text_buffers[1], TEXT_FOREVER);
				else
				{
					if (text_repeat == 1)
						strcpy(text_buffers[1], TEXT_TIMES1);
					else
					{	
						strcpy(text_buffers[1], TEXT_TIMESX);
			    	int_to_string(text_repeat, &text_buffers[1][7]);
					}
				}	
				break;
		
			case 2:
				if (banner_colors == true)
					strcpy(text_buffers[1], TEXT_COLORW);
				else
					strcpy(text_buffers[1], TEXT_COLORB);
				break;
			
			case 3:
				if (scroll_left == true)
					strcpy(text_buffers[1], TEXT_SCROLL_LEFT);
				else
					strcpy(text_buffers[1], TEXT_SCROLL_UP);
				break;
			
			case 4:
				strcpy(text_buffers[1], TEXT_CURSOR1);
				strcpy(text_buffers[2], TEXT_CURSOR2);
				int_to_string(cursor_delay, &text_buffers[3][7]);
				break;
		}
	}
	show_texts();
}

static void restore_texts()
{	
	if (text_mode == RESTORE_TEXTS)
	{
		restore_yes = !restore_yes;
		if (restore_yes == true)
			strcpy(text_buffers[3], TEXT_RESTORE_YES);
		else
			strcpy(text_buffers[3], TEXT_RESTORE_NO);
	}
}

void i_cursor_layer_update_callback(Layer *layer, GContext* ctx) 
{
	int i;
	if (text_mode == SHOW_ALL_CHARS)
	{
		graphics_context_set_stroke_color(ctx, GColorBlack);
		for (i = 0; i < 4; ++i)
			graphics_draw_line(ctx, GPoint(h_start, v_start + i), GPoint(h_start + H_CURSOR_LENGTH, v_start + i));
	}
}


void i_up_single_click_handler(ClickRecognizerRef recognizer, Window *input_window)
{
	
	if (text_mode == SHOW_NEW_MESSAGE)
	{
		if (message_number < NUMBER_OF_MY_MESSAGES)
			++message_number;

		int_to_string(message_number, &text_buffers[2][7]);
	}

	if (text_mode == SHOW_ALL_CHARS)
	{
		if (h_direction == true)
		{
			h_start += H_CHAR_LENGHTH;
			if (h_start > H_CURSOR_START_POS + (H_CHAR_LENGHTH * (H_NBR_OF_CHARS - 1)))
			{
				h_start -= H_CHAR_LENGHTH * 2;
				h_direction = false;
			}
		}
		else
		{
			if (h_start == H_CURSOR_START_POS)
			{
				h_direction = true;
				h_start += H_CHAR_LENGHTH;
			}
			else
				h_start -= H_CHAR_LENGHTH;
		}
		
	    layer_mark_dirty(cursor_layer);
	}

	restore_texts();
	
	if (text_mode == SHOW_SETTINGS)
	{
		switch (screen_mode)
		{
			case 0:
				back_light = !back_light;
				if (back_light == true)
					strcpy(text_buffers[1], TEXT_LIGHTON);
				else
					strcpy(text_buffers[1], TEXT_LIGHTOFF);
				break;
			
			case 1:
				if (text_repeat < 99)
					++text_repeat;
				
				if (text_repeat == 1)
					strcpy(text_buffers[1], TEXT_TIMES1);
				else
				{	
					strcpy(text_buffers[1], TEXT_TIMESX);
				  int_to_string(text_repeat, &text_buffers[1][7]);
				}
				break;
			
			case 2:
				banner_colors = !banner_colors;
				if (banner_colors == true)
					strcpy(text_buffers[1], TEXT_COLORW);
				else
					strcpy(text_buffers[1], TEXT_COLORB);
				break;
			
			case 3:
				scroll_left = !scroll_left;
				if (scroll_left == true)
					strcpy(text_buffers[1], TEXT_SCROLL_LEFT);
				else
					strcpy(text_buffers[1], TEXT_SCROLL_UP);
				break;
			
			case 4:
				if (cursor_delay < MAXIMUM_CURSOR_DELAY)
					++cursor_delay;
				int_to_string(cursor_delay, &text_buffers[3][7]);
				break;
		}
	}	
	show_texts();
}
	
void i_down_single_click_handler(ClickRecognizerRef recognizer, Window *input_window) 
{
	
	if (text_mode == SHOW_NEW_MESSAGE)
	{
		if (message_number > 1)
			--message_number;
		
		strcpy(text_buffers[2], TEXT_EMPTY);
		int_to_string(message_number, &text_buffers[2][7]);
	}
	
	if (text_mode == SHOW_ALL_CHARS)
	{
		if (v_direction == true)
		{
			v_start += V_CHAR_HEIGHT;
			if (v_start > V_CURSOR_START_POS + (V_CHAR_HEIGHT * (V_NBR_OF_CHARS - 1)))
			{
				v_start -= V_CHAR_HEIGHT * 2;
				v_direction = false;
			}
		}
		else
		{
			if (v_start == V_CURSOR_START_POS)
			{
				v_direction = true;
				v_start += V_CHAR_HEIGHT;
			}
			else
				v_start -= V_CHAR_HEIGHT;
		}
		psleep(cursor_delay * 2);
	}
	
	restore_texts();	
	
	if (text_mode == SHOW_SETTINGS)
	{
		switch (screen_mode)
		{
			case 0:
				back_light = !back_light;
				if (back_light == true)
					strcpy(text_buffers[1], TEXT_LIGHTON);
				else
					strcpy(text_buffers[1], TEXT_LIGHTOFF);
				break;
			
			case 1:
				if (text_repeat > 0)
					--text_repeat;
				
				if (text_repeat == FOREVER)
					strcpy(text_buffers[1], TEXT_FOREVER);
				else
				{
					if (text_repeat == 1)
						strcpy(text_buffers[1], TEXT_TIMES1);
					else
						{
						strcpy(text_buffers[1], TEXT_TIMESX);
			    	int_to_string(text_repeat, &text_buffers[1][7]);
					}
				}	
				break;	
			
			case 2:
				banner_colors = !banner_colors;
				if (banner_colors == true)
					strcpy(text_buffers[1], TEXT_COLORW);
				else
					strcpy(text_buffers[1], TEXT_COLORB);
				break;
			
			case 3:
				scroll_left = !scroll_left;
				if (scroll_left == true)
					strcpy(text_buffers[1], TEXT_SCROLL_LEFT);
				else
					strcpy(text_buffers[1], TEXT_SCROLL_UP);
				break;
			
			case 4:
				if (cursor_delay > MINIMUM_CURSOR_DELAY)
					--cursor_delay;
			
				strcpy(text_buffers[3], TEXT_EMPTY);
				int_to_string(cursor_delay, &text_buffers[3][7]);
				break;
		}
	}	
	show_texts();
}

static void set_colors()
{
	if (banner_colors == true)
	{
		color_foreground = COLOR_FALLBACK(GColorYellow, GColorWhite);
		color_background = COLOR_FALLBACK(GColorBlack, GColorBlack);
	}
  else
	{
		color_foreground = COLOR_FALLBACK(GColorRed, GColorBlack);
		color_background = COLOR_FALLBACK(GColorBlack, GColorWhite);
	}
}

static void update_settings()
{
	persist_write_int(P_CYCLES, text_repeat);
	persist_write_int(P_CURSOR, cursor_delay);
	persist_write_bool(P_COLOR, banner_colors);
	persist_write_bool(P_DIRECTION, scroll_left);
	persist_write_bool(P_BACKLIGHT, back_light);
	set_colors();
}


void i_select_single_click_handler(ClickRecognizerRef recognizer, Window *input_window)
{
	char selected_char;
	int i;

	if (text_mode == SHOW_ALL_CHARS)
	{
	    selected_char = text_buffers[(v_start - V_CURSOR_START_POS) / V_CHAR_HEIGHT][(h_start - H_CURSOR_START_POS) / H_CHAR_LENGHTH];
	    i = strlen(buffer_200);

		if (i <= MY_TEXTS_LEN)
	    {
		    buffer_200[i] = selected_char;
		    buffer_200[i + 1] = 0x0;
		    if (i >= H_NBR_OF_CHARS)
			    strncpy(text_buffers[5], &buffer_200[i - H_NBR_OF_CHARS + 1], H_NBR_OF_CHARS);
		    else
			    strcpy(text_buffers[5], buffer_200);	
	    }
        text_layer_set_text(text_layers[5], text_buffers[5]);
	}
	
	if (text_mode == SHOW_NEW_MESSAGE)
	{
		text_mode = SHOW_ALL_CHARS;
		clear_all_texts();
	  strcpy(text_buffers[0], TEXT_ATOZ0);
	  strcpy(text_buffers[1], TEXT_ATOZ1);
	  strcpy(text_buffers[2], TEXT_ATOZ2);
	  strcpy(text_buffers[3], TEXT_ATOZ3);
	  strcpy(text_buffers[4], TEXT_ATOZ4);
	  buffer_200[0] = 0x0;
		show_texts();
    }
	
	if (text_mode == RESTORE_TEXTS)
	{
		restore_my_texts(restore_yes);
		window_stack_pop(false);		
	}
	
	if (text_mode == SHOW_SETTINGS)
	{
		set_colors();
		window_stack_pop(false);		
	}
//APP_LOG(APP_LOG_LEVEL_DEBUG, "char %c, %d", selected_char, i);
}


void i_back_single_click_handler(ClickRecognizerRef recognizer, Window *input_window)
{
	if ((text_mode == SHOW_ALL_CHARS) && (strlen(buffer_200) > 0))
	{
		persist_write_string(message_number, buffer_200);
		banner_mode = SHOW_MY_TEXTS;
		text_number = message_number - 1;
	}
	set_colors();
	window_stack_pop(false);
}

void i_select_long_click_handler(ClickRecognizerRef recognizer, Window *input_window)
{
	int i;
	
	i = strlen(buffer_200);

	if (i > 0)
	{
		buffer_200[--i] = 0x0;
	    if (i >= H_NBR_OF_CHARS)
		    strncpy(text_buffers[5], &buffer_200[i - H_NBR_OF_CHARS], H_NBR_OF_CHARS);
	    else
		    strcpy(text_buffers[5], buffer_200);
		
		show_texts();
	}
}

void i_click_config_provider(Window *input_window) 
{
	window_single_repeating_click_subscribe(BUTTON_ID_UP  , cursor_delay, (ClickHandler) i_up_single_click_handler);
  window_single_repeating_click_subscribe(BUTTON_ID_DOWN, cursor_delay, (ClickHandler) i_down_single_click_handler);
  window_single_click_subscribe(BUTTON_ID_SELECT, (ClickHandler) i_select_single_click_handler);
  window_single_click_subscribe(BUTTON_ID_BACK  , (ClickHandler) i_back_single_click_handler);
  window_long_click_subscribe(BUTTON_ID_SELECT, LONG_CLICK_DELAY, (ClickHandler) i_select_long_click_handler, NULL);
}


void intext_init(void)
{
	input_window = window_create();
	root_layer = window_get_root_layer(input_window);
	mono_font = fonts_load_custom_font(resource_get_handle(MONO_FONT));
	
//	window_set_background_color(input_window, color_foreground);
	
  for(int i = 0; i < NBR_OF_TEXT_LAYERS; ++i) 
	{
		text_layers[i] = text_layer_create(GRect(H_CHAR_START_POS, V_CHAR_START_POS + V_CHAR_HEIGHT * i,  window_bounds.size.w,  window_bounds.size.h));
  	text_layer_set_font(text_layers[i], mono_font);
//text_layer_set_text_color(text_layers[i], color_foreground);
  	layer_add_child(root_layer, (Layer*) text_layers[i]);
	}
	
	cursor_layer = layer_create(window_bounds);
	layer_set_update_proc(cursor_layer, i_cursor_layer_update_callback);
	layer_add_child(root_layer, cursor_layer);
	
	window_set_window_handlers(input_window, (WindowHandlers) {.load = input_window_load});
	
  window_set_click_config_provider(input_window, (ClickConfigProvider) i_click_config_provider);
	text_repeat = persist_exists(P_CYCLES) ? persist_read_int(P_CYCLES) : 1;
	cursor_delay = persist_exists(P_CURSOR) ? persist_read_int(P_CURSOR) : CURSOR_DELAY;
	scroll_left = persist_exists(P_DIRECTION) ? persist_read_bool(P_DIRECTION) : false;
	banner_colors = persist_exists(P_COLOR) ? persist_read_bool(P_COLOR) : true;
	set_colors();
	back_light = persist_exists(P_BACKLIGHT) ? persist_read_bool(P_BACKLIGHT) : true;
}

void intext_deinit(void) 
{
	update_settings();

	for(int i = 0; i < NBR_OF_TEXT_LAYERS; ++i) 
	  text_layer_destroy(text_layers[i]);
	fonts_unload_custom_font(mono_font);
	layer_destroy(cursor_layer);
	window_destroy(input_window);
}
