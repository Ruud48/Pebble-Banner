/*
 *	Scolling large Banner Text (Message) on Pebble watch
 *	Draw large proportional characters eighter horizontal (Left direction) or vertical (Up direction)
 *	using its own font table and scroll them 1 font row at a time.
 *	Every font bit is displayed as a multiple pixel rectangle/circle on the watch screen. 
 */
 
/* 
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the "Software"), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sub-license, and/or sell copies of
 * the Software, and to permit persons to whom the Software is furnished to do so.
 *
 * Ver 1.0  4 July 2016
 *
 */

#include <pebble.h>
#include "common.h"
	

#define STARTBANNERDELAY 1500					// wait before starting movement of banner
#define MESSAGE_DELAY 35							// update banner screen time in milli seconds
#define MAX_MESSAGE_DELAY 1000
#define MIN_MESSAGE_DELAY 5
#define MESSAGE_DELAY_STEP 10
#define TIME_TIMER_UPDATE 1000				// check Watchface time every 1 second
#define INBOX_SIZE  MY_TEXTS_LEN + 1	// to receive text from Phone
#define OUTBOX_SIZE 16								// not used

#ifdef PBL_PLATFORM_CHALK
#define BATT_POS 15
#define CHALK_LAYER_OFFSET 20
#else
#define BATT_POS 3
#define CHALK_LAYER_OFFSET 0
#endif

// 123456789112345678921234567893123456789412345678951234567896123456789712345678981234567899123456789A123456789b123456789c123456789d123456789e123456789f12345678961234567897123456789812345678991234567890
// The line above contains 200 characters		
	
static char my_messages[NUMBER_OF_MY_MESSAGES][MY_TEXTS_LEN + 1] = {   // If you change the texts then temporarily un-comment the for loop in "void main_init(void)" at the bottom
	"Hi, my name is Pebble, what is yours?",
	"What'z up?",
	"HELP ME, Help me, HELP ME !!!",
	"Don't do that!",
	"It wasn't me!",
	"I'm very sorry!",
	"I saw that!",
	"Thanks a million!",
	"I told you so!",
	"The answer is: NO!",
	"That's what she said!",
  "Hello, is it me you are looking for?",
	"I'm Busy, You're an Idiot, Have a Nice Day",
	"Voulez-vous coucher avec moi ce soir?",
 	"Roses are red, violets are blue, a face like yours, belongs in the zoo" 
	};

static char fixed_messages[NUMBER_OF_FIXED_MESSAGES][76] = {       // Fixed Texts are max. 75 long
	"Does anyone really know what time it is?",
 	"Happy Birthday to YOU",
  "Beer is the answer, what was the question?",
  "I HAVE THOSE EXACT SAME EARRINGS!",
	"Is it HOT in here, or is it just me?",
 	"You can never get enough of what you don't want.",
	"Alcohol does not solve problems but neither does milk",
	"With great power comes great electricity bill",
	"I'd luv to kiss ya, but I just washed my hair",
 	"My friend likes to know if you think I am HOT!",
 	"There is very little future in being right, when your boss is wrong!",
	"Hey, I'm afraid I can't let you do that!",
	"I never said most of the things I said.",
	"Do as I say and not as I do!",
	"Your village called; They want their idiot back."
	};


static char menu_level1_texts[LEVEL1_MENU_ITEMS][MENU_TEXT_LENGTH + 1] = {       
	"Show My_Texts    ",
 	"Show Fixed Texts ",
	"Show Time only   ",
	"Show Date + Time ",
	"Reset My_Texts   ",
	"Scrolling Help   ",
	"Single Word Help ",
 	"Enter a New Text ",
 	"Settings         "
	};


static char menu_level3_texts[LEVEL3_MENU_ITEMS][MENU_TEXT_LENGTH + 1] = {       
	"Backlight On?    ",
 	"How many Times?  ",
	
#ifdef PBL_PLATFORM_APLITE
	"White or Black?  ",
#else
	"Yellow or Red?   ",
#endif
	
	"Scroll Left / Up?",
	"Set Cursor Delay?"
	};

#define TEXT_BT_ON  "BT ON"
#define TEXT_BT_OFF "     "
#define TEXT_EMPTY "Empty!"
#define TEXT_ERROR1 "ERR Reset watch"
#define TEXT_NOT_FOUND "No text found"
#define TEXT_RESET_WATCH "ERROR: Factory Reset your Watch!"
#define TEXT_LONG_24_TIME "%A %B %e, Time = %k:%M"	
#define TEXT_LONG_12_TIME "%A %B %e, Time = %l:%M%p"	
	
char buffer_200[BUF200_SIZE + 1];
char status_text[32];								// pos. 4-6 = batt %, 26-30 = "BT ON"
uint8_t text_mode;
uint8_t banner_mode;
uint8_t text_repeat = 1;
uint8_t text_number;
bool back_light = true;
bool banner_colors = true;
bool scroll_left = false;
bool restore_yes = false;
bool banner_change_size = false;
GColor color_background;
GColor color_foreground;
GRect window_bounds;
static uint8_t message_number = 0;
static uint16_t up_message_delay = MESSAGE_DELAY;
static uint16_t left_message_delay = MESSAGE_DELAY;
static uint8_t old8;
static uint8_t new8;
static struct tm *pebble_time;
static char time_text[6] = "00:00"; 				// Needs to be static because it's used by the system later.
static char date_text[12] = "September 00";	// use longest month name
static AppTimer *banner_timer_handle;				// Will be used to cancel timer via `app_timer_cancel_event()`
static AppTimer *time_timer_handle;
Window *time_window; 			
static Window *level1_menu_window;
static Window *level2_menu_window;
static Layer *banner_layer; 								// Layer to store the moving message
static Layer *line_layer;										// Layer to store the line
static Layer *time_layer;
static Layer *b_window_layer;
static TextLayer *text_date_layer;					// Text Layer to store the date
static TextLayer *text_time_layer;					// Text layer to store the time
static TextLayer *text_status_layer;
static BatteryChargeState charge_state;
static bool block_tap = false;							// Block tap events if true
static bool vibe = true;

static SimpleMenuLayer *level1_menu_layer;
static SimpleMenuLayer *level2_menu_layer;

// A simple menu layer can have multiple sections
static SimpleMenuSection level1_menu_sections[LEVEL1_MENU_SECTIONS];
static SimpleMenuSection level2_menu_sections[LEVEL2_MENU_SECTIONS];

// Each section is composed of a number of menu items
static SimpleMenuItem level1_menu_items[LEVEL1_MENU_ITEMS];
static SimpleMenuItem level2_menu_items[LEVEL2_MENU_ITEMS];
static char menu_items_buffer[(MENU_TEXT_LENGTH + 1) * LEVEL1_MENU_ITEMS];
static char menu2_items_buffer[(MENU_TEXT_LENGTH + 1) * LEVEL2_MENU_ITEMS];


static int string_to_int(char string[])
{
  int i, result = 0;
  for (i = 0; (string[i] >= '0') && (string[i] <= '9'); ++i)
    result = (result * 10) + string[i] - '0';
  return result;
//APP_LOG(APP_LOG_LEVEL_DEBUG, "int = %d", result);
}

void int_to_string(int i, char *p)		// only for positive values, p must point at right most position, does not put a zero behind the text
{
  do
		*p-- = '0' + i % 10;
  while ((i /= 10) != 0);
}
		
static void accel_tap(AccelAxisType axis, int32_t direction)	// Called after shaking (tap) the watch
{
	if (block_tap == false)
	{
		block_tap = true;
		light_enable(back_light);						// Switch backlight on or off
		psleep(STARTBANNERDELAY);           // wait a little bit before starting the banner text
		text_index = 0;
		window_stack_push(banner_window,false);
	}
}

// This is called whenever the layer needs to be redrawn.
static void banner_layer_update_callback(Layer *me, GContext* ctx) 
{
	(void)me; 														// Prevents "unused" warnings.

	if ((text_repeat != FOREVER) && (current_text_repeat >= text_repeat))
	{
		current_text_repeat = 0;						// No more scrolls
		light_enable(false);								// Switch backlight off
		block_tap = false;
	  window_stack_pop(false);
	}
	else
	{	
		if (text_index == 0)
		{	
			switch(banner_mode)
			{
				int i;
				
				case SHOW_MY_TEXTS:
					i = persist_read_string(text_number + 1, buffer_200, BUF200_SIZE);
					if ((i == 0) || (i == E_DOES_NOT_EXIST))
						strcpy(buffer_200, TEXT_NOT_FOUND);
					else
						if (i < 0) 
							strcpy(buffer_200, TEXT_RESET_WATCH); 				// should never happen, storage corrupted
					break;
			
				case SHOW_FIXED_TEXTS:
					strcpy(buffer_200, fixed_messages[text_number]);
					break;
		
				case SHOW_TIME_SHORT:
					clock_copy_time_string(buffer_200, BUF200_SIZE);
					break;
			
				case SHOW_TIME_LONG:
					if (clock_is_24h_style())
						strftime(buffer_200, BUF200_SIZE, TEXT_LONG_24_TIME, pebble_time);
					else
						strftime(buffer_200, BUF200_SIZE, TEXT_LONG_12_TIME, pebble_time);
					break;
			}
		}
		display_scrolling_text(ctx, (char *) &buffer_200);
  }
}

static void handle_banner_timer(void *data) 
{
	uint16_t m_delay;
	
	if (block_tap == true)
		layer_mark_dirty(banner_layer);
	
	if (scroll_left == true)
		m_delay = left_message_delay;
	else
		m_delay = up_message_delay;
	
	banner_timer_handle = app_timer_register(m_delay, handle_banner_timer, NULL);
}

static void handle_time_timer(void *data) 
{
	if (connection_service_peek_pebble_app_connection() == true)
	{
		vibe = true;
		if (status_text[26] == ' ')
		{	
			strcpy(&status_text[26], TEXT_BT_ON);
			old8 = 1;															// Force screen update
		}
	}	
	else
	{
		if (vibe == true)
		{
			vibe = false;
			vibes_double_pulse();
			strcpy(&status_text[26], TEXT_BT_OFF);
			old8 = 1;															// Force screen update
		}
	}

	time_t now = time(NULL);
	new8 = now & 8;
	
	if (old8 != new8)						// update the screen every 8 seconds to save the battery
	{	
		old8 = new8;
		pebble_time = localtime(&now);
		strftime(date_text, sizeof(date_text), "%B %e", pebble_time);
		text_layer_set_text(text_date_layer, date_text);
		time_text[0] = ' ';
		clock_copy_time_string(time_text, sizeof(time_text));
		text_layer_set_text(text_time_layer, time_text);
		charge_state = battery_state_service_peek();
		status_text[BATT_POS]= ' ';
		int_to_string(charge_state.charge_percent, &status_text[BATT_POS + 2]);
		status_text[BATT_POS + 3]= '%';
		text_layer_set_text(text_status_layer, status_text);
	}
	time_timer_handle = app_timer_register(TIME_TIMER_UPDATE, handle_time_timer, NULL);
}

static void line_layer_update_callback(Layer *layer, GContext* ctx) 
{
	graphics_context_set_fill_color(ctx, color_foreground);
	graphics_fill_rect(ctx, layer_get_bounds(layer), 0, GCornerNone);
}

void restore_my_texts(bool restore_yes)
{	
	int i;
	
	if (restore_yes == true)
	{
		for (i = 1; i <= NUMBER_OF_MY_MESSAGES; ++i)
		{
			persist_delete(i);
			persist_write_string(i, (const char*) &my_messages[i - 1]);
		}
	}
}

static void menu1_select_callback(int index, void *ctx) 
{
	text_mode = index;
	
	switch(index)
	{
		case SHOW_MY_TEXTS:
		case SHOW_FIXED_TEXTS:
			window_stack_push(level2_menu_window, false);  	
			break;
		
		case SHOW_TIME_SHORT:
		case SHOW_TIME_LONG:
			banner_mode = index;
			window_stack_pop(false);
			break;
			
		case RESTORE_TEXTS:
			show_input_window(index);							
			break;
			
		case SCROLL_HELP:
			window_stack_push(scroll_window, false);
			break;
			
		case ONE_WORD_HELP:
			window_stack_push(word_window, false);
			break;
		
		case SHOW_NEW_MESSAGE:
			show_input_window(index);							
			break;
		
		case SHOW_SETTINGS:
			window_stack_push(level2_menu_window, false);
			break;
    }
}		

// This initializes the menu upon window load
static void level1_menu_window_load(Window *level1_menu_window) 
{
	uint32_t menu_index;
	char *menu_buffer = menu_items_buffer;
	
	for (menu_index = 0; menu_index < LEVEL1_MENU_ITEMS; ++menu_index)
	{
		strncpy(menu_buffer, menu_level1_texts[menu_index], MENU_TEXT_LENGTH);
		menu_buffer[MENU_TEXT_LENGTH] = 0x0;
		level1_menu_items[menu_index] = (SimpleMenuItem)
		{ 
			.title = menu_buffer,
			.callback = menu1_select_callback,
		};
		menu_buffer += MENU_TEXT_LENGTH + 1;
	}

  // Bind the menu items to the corresponding menu sections
	level1_menu_sections[0] = (SimpleMenuSection){
    .num_items = menu_index,
    .items = level1_menu_items,
	};

  // Now we prepare to initialize the simple menu layer
  // We need the bounds to specify the simple menu layer's viewport size
  // In this case, it'll be the same as the window's
	Layer *menu1_layer = window_get_root_layer(level1_menu_window);
	GRect bounds = layer_get_frame(menu1_layer);

  // Initialize the simple menu layer
	level1_menu_layer = simple_menu_layer_create(bounds, level1_menu_window, level1_menu_sections, LEVEL1_MENU_SECTIONS, NULL);

  // Add it to the window for display
	layer_add_child(menu1_layer, simple_menu_layer_get_layer(level1_menu_layer));
}

static void menu2_select_callback(int index, void *ctx) 
{
	banner_mode = text_mode;
	text_number = index;
	window_stack_pop(false);
}

static void menu3_select_callback(int index, void *ctx) 
{
	show_input_window(index);							
}


// This initializes the menu upon window load
static void level2_menu_window_load(Window *level2_menu_window) 
{
	uint32_t menu_index = 0;
	char *menu_buffer = menu2_items_buffer;
	char *p;
	int i, j;
	
	switch(text_mode)
	{
		case SHOW_MY_TEXTS:
			for (menu_index = 0; menu_index < NUMBER_OF_MY_MESSAGES; ++menu_index)
			{
				j = menu_index + 1;
				p = menu_buffer;
				
				if (j < 10)
				{
					*p   = '0' + j;
					*++p = ' ';
					i = 2;
				}
				else
				{
					*p   = '0' + (j / 10);
					*++p = '0' + (j % 10);
					*++p = ' ';
					i = 3;
				}
				
				if (persist_get_size(j) <= 0)
				{
					strcpy(++p, TEXT_EMPTY); 	
				}
				else
				{
					if (persist_read_string(j, buffer_200, BUF200_SIZE) < 0)
						strcpy(menu_buffer, TEXT_ERROR1); 		// should never happen
					else
						strncpy(++p, buffer_200, MENU_TEXT_LENGTH - i);
				}

				menu_buffer[MENU_TEXT_LENGTH] = 0x0;
				// This is an example of how you'd set a simple menu item
				level2_menu_items[menu_index] = (SimpleMenuItem)
					{	
						.title = menu_buffer,
						.callback = menu2_select_callback,
		    	};
		    menu_buffer += MENU_TEXT_LENGTH + 1;
			}	
			break;
				
		case SHOW_FIXED_TEXTS:
			for (menu_index = 0; menu_index < NUMBER_OF_FIXED_MESSAGES; ++menu_index)
			{
				strncpy(menu_buffer, fixed_messages[menu_index], MENU_TEXT_LENGTH);
				menu_buffer[MENU_TEXT_LENGTH] = 0x0;
				// This is an example of how you'd set a simple menu item
				level2_menu_items[menu_index] = (SimpleMenuItem)
			    { 
				    .title = menu_buffer,
				    .callback = menu2_select_callback,
			    };
			  menu_buffer += MENU_TEXT_LENGTH + 1;
			}
			break;
		
		case SHOW_SETTINGS:
			for (menu_index = 0; menu_index < LEVEL3_MENU_ITEMS; ++menu_index)
			{
				strncpy(menu_buffer, menu_level3_texts[menu_index], MENU_TEXT_LENGTH);
				menu_buffer[MENU_TEXT_LENGTH] = 0x0;
				// This is an example of how you'd set a simple menu item
				level2_menu_items[menu_index] = (SimpleMenuItem)
			    { 
				    .title = menu_buffer,
				    .callback = menu3_select_callback,
			    };
			  menu_buffer += MENU_TEXT_LENGTH + 1;
      }
			break;
	}
		
  // Bind the menu items to the corresponding menu sections
	level2_menu_sections[0] = (SimpleMenuSection){
    .num_items = menu_index,
    .items = level2_menu_items,
		};

  // Now we prepare to initialize the simple menu layer
  // We need the bounds to specify the simple menu layer's viewport size
  // In this case, it'll be the same as the window's
	Layer *menu2_layer = window_get_root_layer(level2_menu_window);
	GRect bounds = layer_get_frame(menu2_layer);

  // Initialize the simple menu layer
	level2_menu_layer = simple_menu_layer_create(bounds, level2_menu_window, level2_menu_sections, LEVEL2_MENU_SECTIONS, NULL);

  // Add it to the window for display
	layer_add_child(menu2_layer, simple_menu_layer_get_layer(level2_menu_layer));
}

// Deinitialize resources on window unload that were initialized on window load
void level1_menu_window_unload(Window *menu1_window) 
{
	block_tap = false;
	simple_menu_layer_destroy(level1_menu_layer);
}

void level2_menu_window_unload(Window *menu2_window) 
{
  simple_menu_layer_destroy(level2_menu_layer);
	window_stack_pop(false);
}

void banner_window_appear(Window *banner_window) 
{
	current_text_repeat = 0;
	persist_write_int(P_LAST_USED, banner_mode);
	persist_write_int(P_LAST_TEXT, text_number);
	handle_banner_timer(NULL);
}

void banner_window_disappear(Window *banner_window) 
{
	app_timer_cancel(banner_timer_handle);
	old8 = 1;
}

void time_window_appear(Window *time_window) 
{
	old8 = 1;
	memset(&status_text[0], 0x20, 31);
	status_text[31] = 0x0;
	handle_time_timer(NULL);
}

static void time_window_disappear(Window *time_window) 
{
	app_timer_cancel(time_timer_handle);
}

static void show_message() 
{
	block_tap = true;
	light_enable(back_light);					// Switch backlight on or off
	text_index = 0;
	window_stack_push(banner_window, false);
}

static void handle_appmessage_receive(DictionaryIterator *received, void *context)
{
	Tuple *bnumber_tuple = dict_find(received, MESSAGE_KEY_mn);
	if (bnumber_tuple)
	{
		message_number = string_to_int(bnumber_tuple->value->cstring);
		if ((message_number < 1) || (message_number > NUMBER_OF_MY_MESSAGES))
			message_number = 1;
	}

	Tuple *btext1_tuple = dict_find(received, MESSAGE_KEY_t1);
	if (btext1_tuple)
	{
		int i = strlen(btext1_tuple->value->cstring);
		if ((i > 0) && (i <= MY_TEXTS_LEN))
		{
			persist_write_string(message_number, btext1_tuple->value->cstring);
			banner_mode = SHOW_MY_TEXTS;
			text_number = message_number - 1;
			show_message();
		}	
//  APP_LOG(APP_LOG_LEVEL_DEBUG, "Message: %d, %d, %s", strlen(btext1_tuple->value->cstring), message_number, btext1_tuple->value->cstring);
	}
}

static void time_up_click_handler(ClickRecognizerRef recognizer, Window *time_window) 
{
	show_message();
}

static void time_select_click_handler(ClickRecognizerRef recognizer, Window *time_window) 
{
	block_tap = true;
	window_stack_push(level1_menu_window, false);
}

static void time_click_config_provider(Window *time_window) 
{
  window_single_click_subscribe(BUTTON_ID_SELECT, (ClickHandler) time_select_click_handler);
  window_single_click_subscribe(BUTTON_ID_UP, (ClickHandler) time_up_click_handler);
}

static void banner_select_click_handler(ClickRecognizerRef recognizer, Window *banner_window) 
{
	banner_change_size = !banner_change_size;
}

static void banner_select_long_click_handler(ClickRecognizerRef recognizer, Window *banner_window) 
{
	;
}

static void banner_select_long_click_release_handler(ClickRecognizerRef recognizer, Window *banner_window) 
{
	text_index = 0;
	scroll_left = !scroll_left;
}

static void banner_up_click_handler(ClickRecognizerRef recognizer, Window *banner_window) 
{
	if (banner_change_size == true)
	{
		if (scroll_left == true)
		{
			if (left_char_multiplier < MAX_CHAR_MULTIPLIER)
				++left_char_multiplier;
		}
		else
		{
			if (up_char_multiplier < MAX_CHAR_MULTIPLIER)
				++up_char_multiplier;
		}
	}
	else
	{
		if (scroll_left == true)
		{
			if (left_message_delay >= MIN_MESSAGE_DELAY + MESSAGE_DELAY_STEP)
				left_message_delay -= MESSAGE_DELAY_STEP;
		}
		else
		{
			if (up_message_delay >= MIN_MESSAGE_DELAY + MESSAGE_DELAY_STEP)
				up_message_delay -= MESSAGE_DELAY_STEP;
		}
	}
}


static void banner_down_click_handler(ClickRecognizerRef recognizer, Window *banner_window) 
{
	if (banner_change_size == true)
	{
		if (scroll_left == true)
		{
			if (left_char_multiplier > 1)
				--left_char_multiplier;
		}
		else
		{
			if (up_char_multiplier > 1)
				--up_char_multiplier;
		}
	}
	else
	{
		if (scroll_left == true)
		{
			if (left_message_delay < MAX_MESSAGE_DELAY)
				left_message_delay += MESSAGE_DELAY_STEP;
		}
		else
		{
			if (up_message_delay < MAX_MESSAGE_DELAY)
				up_message_delay += MESSAGE_DELAY_STEP;
		}
	}
}

static void banner_back_click_handler(ClickRecognizerRef recognizer, Window *banner_window) 
{
	light_enable(false);
	block_tap = false;
	window_stack_pop(false);
}

static void banner_click_config_provider(Window *banner_windowt) 
{
  window_single_click_subscribe(BUTTON_ID_SELECT, (ClickHandler) banner_select_click_handler);
  window_long_click_subscribe(BUTTON_ID_SELECT, LONG_CLICK_DELAY, (ClickHandler) banner_select_long_click_handler, (ClickHandler) banner_select_long_click_release_handler);
  window_single_click_subscribe(BUTTON_ID_UP, (ClickHandler) banner_up_click_handler);
	window_single_click_subscribe(BUTTON_ID_DOWN, (ClickHandler) banner_down_click_handler);
	window_single_click_subscribe(BUTTON_ID_BACK, (ClickHandler) banner_back_click_handler);
}

// Handle the start-up of the app
static void main_init(void) 
{
	
	color_foreground = COLOR_FALLBACK(GColorYellow, GColorWhite);
	color_background = COLOR_FALLBACK(GColorBlack, GColorBlack);
	
	// Create our app's base window
	banner_window = window_create();
//	window_set_background_color(banner_window, color_background);
	b_window_layer = window_get_root_layer(banner_window);
	window_bounds = layer_get_bounds(b_window_layer);

	// Init the layer that shows the moving text
	banner_layer = layer_create(layer_get_frame(b_window_layer));
	layer_set_update_proc(banner_layer, banner_layer_update_callback); 	// Set the drawing callback function for the layer.
	layer_add_child(b_window_layer, banner_layer); 											// Add the child to the app's base banner_window
	window_set_window_handlers(banner_window, (WindowHandlers)
		{
		.appear = banner_window_appear,
		.disappear = banner_window_disappear
		});
	
	window_set_click_config_provider(banner_window, (ClickConfigProvider) banner_click_config_provider);

	time_window = window_create();
	window_set_background_color(time_window, color_background);
	window_set_window_handlers(time_window, (WindowHandlers)
		{
		.appear = time_window_appear,
		.disappear = time_window_disappear
		});
	
	time_layer = window_get_root_layer(time_window);

	
	text_date_layer = text_layer_create(GRect(9 + CHALK_LAYER_OFFSET, 68,  window_bounds.size.w - 9 - CHALK_LAYER_OFFSET,  window_bounds.size.h - 68));
	text_layer_set_text_color(text_date_layer, color_foreground);
	text_layer_set_background_color(text_date_layer, color_background);
	text_layer_set_font(text_date_layer, fonts_get_system_font(FONT_KEY_ROBOTO_CONDENSED_21));
	layer_add_child(time_layer, text_layer_get_layer(text_date_layer));

	text_time_layer = text_layer_create(GRect(7 + CHALK_LAYER_OFFSET, 92,  window_bounds.size.w - 7 - CHALK_LAYER_OFFSET,  window_bounds.size.h - 92));
	text_layer_set_text_color(text_time_layer, color_foreground);
	text_layer_set_background_color(text_time_layer, color_background);
	text_layer_set_font(text_time_layer, fonts_get_system_font(FONT_KEY_ROBOTO_BOLD_SUBSET_49));
	layer_add_child(time_layer, text_layer_get_layer(text_time_layer));

  text_status_layer = text_layer_create(GRect(5, 5,  window_bounds.size.w - 5, 40 ));
	text_layer_set_text_color(text_status_layer, color_foreground);
	text_layer_set_background_color(text_status_layer, color_background);
	text_layer_set_font(text_status_layer, fonts_get_system_font(FONT_KEY_GOTHIC_14));
	layer_add_child(time_layer, text_layer_get_layer(text_status_layer));
	
	line_layer = layer_create(GRect(8 + CHALK_LAYER_OFFSET, 97, 126, 2));
	layer_set_update_proc(line_layer, line_layer_update_callback);
	layer_add_child(time_layer, line_layer);
	window_set_click_config_provider(time_window, (ClickConfigProvider) time_click_config_provider);

	window_stack_push(time_window, false);
	
	level1_menu_window = window_create();
	window_set_window_handlers(level1_menu_window, (WindowHandlers)
    {
		.load = level1_menu_window_load,
		.unload = level1_menu_window_unload
    });

	level2_menu_window = window_create();
	window_set_window_handlers(level2_menu_window, (WindowHandlers)
    {
		.load = level2_menu_window_load,
		.unload = level2_menu_window_unload
    });
	
	accel_tap_service_subscribe(accel_tap);	

	app_message_register_inbox_received(&handle_appmessage_receive);
	app_message_open(INBOX_SIZE, OUTBOX_SIZE);

	uint32_t i;

	
////////// Temporarily Un-Comment this for loop if you have changed "My_Texts"  **********************************
//	for (i = 1; i <= NUMBER_OF_MY_MESSAGES; ++i)
//		persist_delete(i);

	
	
	for (i = 1; i <= NUMBER_OF_MY_MESSAGES; ++i)
	{	
		if (persist_get_size(i) <= 0)
		{
			persist_delete(i);
			persist_write_string(i, (const char*) &my_messages[i - 1]);
		}
	}
	
	up_message_delay = persist_exists(P_UP_DELAY) ? persist_read_int(P_UP_DELAY) : MESSAGE_DELAY;
	left_message_delay = persist_exists(P_LEFT_DELAY) ? persist_read_int(P_LEFT_DELAY) : MESSAGE_DELAY;
	up_char_multiplier = persist_exists(P_UP_SIZE) ? persist_read_int(P_UP_SIZE) : MAX_CHAR_MULTIPLIER;
	left_char_multiplier = persist_exists(P_LEFT_SIZE) ? persist_read_int(P_LEFT_SIZE) : MAX_CHAR_MULTIPLIER;
	banner_mode = persist_exists(P_LAST_USED) ? persist_read_int(P_LAST_USED) : 0;
	text_number = persist_exists(P_LAST_TEXT) ? persist_read_int(P_LAST_TEXT) : 0;
}

static void main_deinit(void) 
{
	persist_write_int(P_UP_DELAY, up_message_delay);
	persist_write_int(P_LEFT_DELAY, left_message_delay);
	persist_write_int(P_UP_SIZE, up_char_multiplier);
	persist_write_int(P_LEFT_SIZE, left_char_multiplier);
	text_layer_destroy(text_time_layer);
  text_layer_destroy(text_date_layer);
  text_layer_destroy(text_status_layer);
  layer_destroy(line_layer);
  layer_destroy(banner_layer);
  window_destroy(banner_window);
  window_destroy(time_window);
  window_destroy(level1_menu_window);
  window_destroy(level2_menu_window);
	app_message_deregister_callbacks();
  accel_tap_service_unsubscribe();	
}


// The main event/run loop for our app

int main() 
{
	main_init();
	intext_init();
	scroll_help_init();
	one_word_init();
	scroll_init();
  app_event_loop();
	scroll_deinit();
	one_word_deinit();
	scroll_help_deinit();
	intext_deinit();
  main_deinit();
}
