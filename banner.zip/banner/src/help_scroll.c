/*
 * Ver 1.0  4 July 2016
*/ 


#include "pebble.h"
#include <common.h>

	
#define	MAX_TEXT_HEIGHT 2500 //2400		// depends on length of help text !!!!!!
	
Window *scroll_window;

// This is a scroll layer
static ScrollLayer *scroll_layer;

// We also use a text layer to scroll in the scroll layer
static TextLayer *scroll_text_layer;

#ifdef PBL_PLATFORM_APLITE
char help_text[] = "BANNER HELP  V1.0\nYou may overwrite all 15 texts in \"My_Texts\" with your own texts.\nThere are also 15 \"Fixed\" texts which cannot be changed.\nAll \"My_Texts\" may be up to 125 characters long.\nAfter selecting a text the time and date will be displayed and the selected text will only be shown if you press the Up button or shake the watch.\nWhile the text is scrolling you may change the scroll speed with the Up/Down buttons. If you press the Select button once while the text is scrolling then you may change the character size with the Up/Down buttons.\nPressing the Select button for 1 second will flip between the Up or Left movement of the text.\nHOW TO ENTER A NEW TEXT\nNew texts may be entered on your phone or on your watch.\nOn your PHONE: Start the Pebble App, select Apps, scroll to “Scrolling Banner” and press the Gear Icon.\nOn your WATCH: Use the Up/Down buttons to select the number (1-15) of the My_Texts to be replaced and press Select.\nMove the cursor to the correct character by holding down the Up or Down button.\nPress Select to accept the character.\nA long press of the Select button deletes the last character entered.\nPress the Back button to store the entered text in \"My_Texts\".\n     SETTINGS\nThe scrolling texts can be shown with the backlight On or Off.\n\"How many Times?\" allows for setting the number of times the text will be shown, 0 = forever.\n\"White or Black?\" allows for changing the color of the scrolling texts.\n\"Set Cursor Delay?\" sets the amount of milliseconds to wait before the cursor moves to the next character while entering a new text.\n  *******";
#else
char help_text[] = "BANNER HELP  V1.0\nYou may overwrite all 15 texts in \"My_Texts\" with your own texts.\nThere are also 15 \"Fixed\" texts which cannot be changed.\nAll \"My_Texts\" may be up to 125 characters long.\nAfter selecting a text the time and date will be displayed and the selected text will only be shown if you press the Up button or shake the watch.\nWhile the text is scrolling you may change the scroll speed with the Up/Down buttons. If you press the Select button once while the text is scrolling then you may change the character size with the Up/Down buttons.\nPressing the Select button for 1 second will flip between the Up or Left movement of the text.\nHOW TO ENTER A NEW TEXT\nNew texts may be entered on your phone or on your watch.\nOn your PHONE: Start the Pebble App, select Apps, scroll to “Scrolling Banner” and press the Gear Icon.\nOn your WATCH: Use the Up/Down buttons to select the number (1-15) of the My_Texts to be replaced and press Select.\nMove the cursor to the correct character by holding down the Up or Down button.\nPress Select to accept the character.\nA long press of the Select button deletes the last character entered.\nPress the Back button to store the entered text in \"My_Texts\".\n     SETTINGS\nThe scrolling texts can be shown with the backlight On or Off.\n\"How many Times?\" allows for setting the number of times the text will be shown, 0 = forever.\n\"Yellow or Red?\" allows for changing the color of the scrolling texts.\n\"Set Cursor Delay?\" sets the amount of milliseconds to wait before the cursor moves to the next character while entering a new text.\n       *******\n\n\n\n\n";
#endif

// Setup the scroll layer on window load
// We do this here in order to be able to get the max used text size
static void scroll_window_load(Window *scroll_window) 
{
	Layer *scroll_window_layer = window_get_root_layer(scroll_window);
  GRect bounds = layer_get_frame(scroll_window_layer);
#ifdef PBL_PLATFORM_CHALK
  GRect max_text_bounds = GRect(5, 64, bounds.size.w - 5, MAX_TEXT_HEIGHT);
#else
	GRect max_text_bounds = GRect(0, 0, bounds.size.w, MAX_TEXT_HEIGHT);
#endif

  // Initialize the scroll layer
  scroll_layer = scroll_layer_create(bounds);

  // This binds the scroll layer to the window so that up and down map to scrolling
  // You may use scroll_layer_set_callbacks to add or override interactivity
  scroll_layer_set_click_config_onto_window(scroll_layer, scroll_window);

  // Initialize the text layer
  scroll_text_layer = text_layer_create(max_text_bounds);
  text_layer_set_text(scroll_text_layer, help_text);

  // Change the font to a nice readable one
  // This is system font; you can inspect pebble_fonts.h for all system fonts
  // or you can take a look at feature_custom_font to add your own font
  text_layer_set_font(scroll_text_layer, fonts_get_system_font(FONT_KEY_GOTHIC_24_BOLD));

  // Trim text layer and scroll content to fit text box
  GSize max_size = text_layer_get_content_size(scroll_text_layer);
  text_layer_set_size(scroll_text_layer, max_size);
  scroll_layer_set_content_size(scroll_layer, GSize(bounds.size.w, max_size.h + 6));

  // Add the layers for display
  scroll_layer_add_child(scroll_layer, text_layer_get_layer(scroll_text_layer));
 	layer_add_child(scroll_window_layer, scroll_layer_get_layer(scroll_layer));
}

static void scroll_window_unload(Window *scroll_window) 
{
 	text_layer_destroy(scroll_text_layer);
 	scroll_layer_destroy(scroll_layer);
}

void scroll_help_init(void)
{
 	scroll_window = window_create();
 	window_set_window_handlers(scroll_window, (WindowHandlers){
   	.load = scroll_window_load,
   	.unload = scroll_window_unload,
		});
}

void scroll_help_deinit(void)
{
	window_destroy(scroll_window);
}
