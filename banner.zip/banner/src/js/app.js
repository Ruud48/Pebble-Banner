
// Ver. 1.0 4 July 2016

var Clay = require('pebble-clay');
var clayConfig = require('./config');
var clay = new Clay(clayConfig);


Pebble.addEventListener("ready", function(e)
	{
//		console.log("Ready");		
	});
