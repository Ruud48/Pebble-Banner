
// Ver. 1.0 4 July 2016

module.exports = [
	{
    "type": "heading",
    "id": "main-heading",
    "defaultValue": "Banner Input Page",
    "size": 1
  },
	{
    "type": "section",
    "items": [
      {
        "type": "input",
        "messageKey": "mn",
        "defaultValue": "1",
        "label": "Text number 1 - 15",
				"attributes": {
					"type": "number",
					"min": "1",
					"max": "15",
					"maxlength": "2"
					}
      },
      {
        "type": "input",
        "messageKey": "t1",
        "defaultValue": "",
				"label": "Text (max. 125 characters).",
				"attributes": {
					"maxlength": "125"
					}
      },
			{
    		"type": "submit",
    		"defaultValue": "Save"
 			},
			{
  			"type": "text",
  			"defaultValue": "BANNER HELP V1.0<br>You may overwrite all 15 texts in My_Texts with your own texts.<br>There are also 15 Fixed texts which cannot be changed.<br>All My_Texts may be up to 125 characters long.<br>After selecting a text on the watch the time and date will be displayed and the selected text will only be shown if you press the Up button or shake the watch.<br>While the text is scrolling you may change the scroll speed with the Up/Down buttons.<br>If you press the Select button once while the text is scrolling then you can change the character size with the Up/Down buttons.<br>Pressing the Select button for 1 second will flip between the Up or Left movement of the text.<br><br>HOW TO ENTER A NEW TEXT ON THE WATCH<br>Use the Up/Down buttons to select the number (1-15) of the My_Texts to be replaced and press Select.<br>Move the cursor to the correct character by holding down the Up/Down button.<br>Press Select to accept the character.<br>A long press of the Select button deletes the last character entered.<br>Press the Back button to store the entered text in My_Texts.<br>New My_Texts may also be entered above.<br><br>SETTINGS:<br>The scrolling texts can be shown with the backlight On or Off.<br>How many Times? allows for setting the number of times the text will be shown, 0 = forever.<br>White or Black? / Yellow or Red? allows for changing the color of the scrolling texts.<br>Set Cursor Delay? sets the amount of milliseconds to wait before the cursor moves to the next character while creating a new text.<br><br>SINGLE WORD HELP<br>Use the Up/Down buttons to change the speed of the display.<br><br>Source is at: https://github.com/Ruud48/Pebble-Banner<br>"
			}]
	 }	
];
