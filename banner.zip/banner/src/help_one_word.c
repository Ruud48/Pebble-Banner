/*
 * Ver 1.0  4 July 2016
*/ 


#include "pebble.h"
#include <common.h>
	
#define MAX_WORD_LENGTH 13
#define SHORT_WORDS 3
#define LF 0x0A
#define BASE_WORD_DELAY 400
#define MAX_WORD_DELAY 800
#define MIN_WORD_DELAY 15
#define WORD_DELAY_STEP 25

#define H_LINE_SIZE 114
#define V_CHAR_SPACE 32
#define H_CHAR_LEN 140

Window *word_window;

TextLayer *word_text_layer;
static Layer *top_line_layer;								// Layer to store the line
static GRect top_line_frame;
static Layer *bottom_line_layer;						// Layer to store the line
static GRect bottom_line_frame;

static AppTimer *one_word_timer_handle;			// Can be used to cancel timer via `app_timer_cancel_event()`

static char one_word[MAX_WORD_LENGTH + 1];
static int help_text_index = 0;
int base_word_delay;
int delay;
static bool pause1;

static void one_word_timer(void *data) 
{
	int i, word_length, help_text_length;
	char c;
		
	word_length = MAX_WORD_LENGTH;
	help_text_length = strlen(help_text);
	
	if (help_text_index >= help_text_length)
	{
		psleep(2000);
		light_enable(false);						// Switch backlight off
	  window_stack_pop(false);
	}
	else
	{
 		if ((help_text_index + MAX_WORD_LENGTH) > help_text_length)
			word_length = (help_text_length - help_text_index) + 1;
		
		delay = base_word_delay * 2;
		for (i = 0; i < word_length; ++i)
		{
			one_word[i] = help_text[help_text_index++];
		
			if (one_word[i] == ' ')
			{
  			one_word[i] = 0;
				break;
			}
		
			if (one_word[i] == LF)
			{
	  		one_word[i] = 0;
				delay = (base_word_delay * 2) + (base_word_delay / 3);   
				break;
			}
		}

		if (i <= SHORT_WORDS)
			delay = base_word_delay;
	
		if (i > 1)
		{
			c = one_word[i - 1];
			if ((c == '.') || (c == ',') || (c == ':') || (c == ';') || (c == '?') || (c == '!'))
				delay += base_word_delay;
		}
		text_layer_set_text(word_text_layer, one_word);	
		one_word_timer_handle = app_timer_register(delay, one_word_timer, NULL);	
	}
}
	

static void top_line_layer_update_callback(Layer *layer, GContext* ctx) 
{
	graphics_context_set_fill_color(ctx, GColorWhite);
	graphics_fill_rect(ctx, layer_get_bounds(layer), 0, GCornerNone);
}

static void bottom_line_layer_update_callback(Layer *layer, GContext* ctx) 
{
	graphics_context_set_fill_color(ctx, GColorWhite);
	graphics_fill_rect(ctx, layer_get_bounds(layer), 0, GCornerNone);
}

static void one_word_window_appear(Window *word_window)
{
	help_text_index = 0;
	light_enable(true);								// Switch backlight on
	base_word_delay = BASE_WORD_DELAY;
	pause1 = false;
	one_word_timer(NULL);	
}

static void one_word_window_disappear(Window *word_window)
{
	light_enable(false);							// Switch backlight off
}


static void word_up_click_handler(ClickRecognizerRef recognizer, Window *word_window) 
{
	if (base_word_delay < MAX_WORD_DELAY)
		base_word_delay += WORD_DELAY_STEP;
}


static void word_down_click_handler(ClickRecognizerRef recognizer, Window *word_window) 
{
	if (base_word_delay > MIN_WORD_DELAY)
		base_word_delay -= WORD_DELAY_STEP;
//APP_LOG(APP_LOG_LEVEL_DEBUG, "Delay is: %d", base_word_delay);
}

static void word_select_click_handler(ClickRecognizerRef recognizer, Window *word_window) 
{
	if (pause1 == false)
	{
		app_timer_cancel(one_word_timer_handle);	
		light_enable(false);						// Switch backlight off
	}
	else
	{
		light_enable(true);							// Switch backlight on
		one_word_timer(NULL);	
	}
	pause1 = !pause1;
}


static void word_click_config_provider(Window *word_windowt) 
{
  window_single_click_subscribe(BUTTON_ID_UP, (ClickHandler) word_up_click_handler);
	window_single_click_subscribe(BUTTON_ID_DOWN, (ClickHandler) word_down_click_handler);
	window_single_click_subscribe(BUTTON_ID_SELECT, (ClickHandler) word_select_click_handler);
}

void one_word_deinit(void) 
{
  layer_destroy(top_line_layer);
  layer_destroy(bottom_line_layer);
  text_layer_destroy(word_text_layer);
 	window_destroy(word_window);
}

void one_word_init(void) 
{
  word_window = window_create();
  window_set_background_color(word_window, GColorBlack);
	window_set_window_handlers(word_window, (WindowHandlers)
    {
		.appear = one_word_window_appear,
		.disappear = one_word_window_disappear
    });

  Layer *one_word_layer = window_get_root_layer(word_window);

  word_text_layer = text_layer_create(GRect((window_bounds.size.w - H_CHAR_LEN) / 2, (window_bounds.size.h -  V_CHAR_SPACE) / 2, H_CHAR_LEN, V_CHAR_SPACE));
  text_layer_set_text_color(word_text_layer, GColorWhite);
  text_layer_set_background_color(word_text_layer, GColorClear);
//  text_layer_set_font(word_text_layer, fonts_get_system_font(FONT_KEY_BITHAM_30_BLACK));
	text_layer_set_font(word_text_layer, fonts_get_system_font(FONT_KEY_GOTHIC_24_BOLD));
	text_layer_set_text_alignment(word_text_layer, GTextAlignmentCenter);
	layer_add_child(one_word_layer, text_layer_get_layer(word_text_layer));
	window_set_click_config_provider(word_window, (ClickConfigProvider) word_click_config_provider);

	top_line_frame = GRect((window_bounds.size.w - H_LINE_SIZE) / 2, (window_bounds.size.h -  V_CHAR_SPACE) / 2, H_LINE_SIZE, 2);
	top_line_layer = layer_create(top_line_frame);
	layer_set_update_proc(top_line_layer, top_line_layer_update_callback);
	layer_add_child(one_word_layer, top_line_layer);

	bottom_line_frame = GRect((window_bounds.size.w - H_LINE_SIZE) / 2, (window_bounds.size.h -  V_CHAR_SPACE) / 2 +  V_CHAR_SPACE, H_LINE_SIZE, 2);
	bottom_line_layer = layer_create(bottom_line_frame);
	layer_set_update_proc(bottom_line_layer, bottom_line_layer_update_callback);
	layer_add_child(one_word_layer, bottom_line_layer);
}
