/*
 * Ver 1.0  4 July 2016
*/

#define MAX_CHAR_MULTIPLIER 9

#define SHOW_MY_TEXTS 0
#define SHOW_FIXED_TEXTS 1
#define SHOW_TIME_SHORT 2
#define SHOW_TIME_LONG 3
#define RESTORE_TEXTS 4
#define SCROLL_HELP 5
#define ONE_WORD_HELP 6
#define SHOW_NEW_MESSAGE 7
#define SHOW_SETTINGS 8
	
#define SHOW_ALL_CHARS 99
	
#define P_CYCLES 100
#define P_CURSOR 101
#define P_COLOR 102
#define P_DIRECTION 103
#define P_BACKLIGHT 104	
#define P_UP_DELAY 105	
#define P_UP_SIZE 106	
#define P_LEFT_DELAY 107	
#define P_LEFT_SIZE 108	
#define P_LAST_USED 109	
#define P_LAST_TEXT 110	
	
	
#define LEVEL1_MENU_SECTIONS 1
#define LEVEL1_MENU_ITEMS 9
#define LEVEL2_MENU_SECTIONS 1
#define LEVEL2_MENU_ITEMS 15	
#define LEVEL3_MENU_ITEMS 5
#define NUMBER_OF_MY_MESSAGES LEVEL2_MENU_ITEMS		
#define NUMBER_OF_FIXED_MESSAGES LEVEL2_MENU_ITEMS
#define MENU_TEXT_LENGTH 34 									// Allow for 17 double byte characters
#define	FOREVER 0
#define LONG_CLICK_DELAY 700

#define MY_TEXTS_LEN 125											// Max lenght of My_Texts	
#define BUF200_SIZE 200
extern char buffer_200[BUF200_SIZE + 1];
extern uint8_t text_mode;
extern uint8_t banner_mode;
extern uint8_t text_repeat;
extern uint8_t text_number;
extern char help_text[];
extern bool back_light;
extern bool banner_colors;
extern bool scroll_left;
extern bool restore_yes;
extern GColor color_background;
extern GColor color_foreground;

extern uint8_t left_char_multiplier;
extern uint8_t up_char_multiplier;
extern uint8_t text_index;
extern uint8_t current_text_repeat;
extern GRect window_bounds;

extern Window *word_window;
extern Window *scroll_window;
extern Window *banner_window; 
extern Window *time_window;

void display_scrolling_text(GContext* ctx, char *text);

void i_down_single_click_handler(ClickRecognizerRef recognizer, Window *input_window);
void i_up_single_click_handler(ClickRecognizerRef recognizer, Window *input_window);
void i_cursor_layer_update_callback(Layer *layer, GContext* ctx);
void i_select_single_click_handler(ClickRecognizerRef recognizer, Window *input_window);
void i_back_single_click_handler(ClickRecognizerRef recognizer, Window *input_window);
void i_select_long_click_handler(ClickRecognizerRef recognizer, Window *input_window);
void i_click_config_provider(Window *input_window);
void intext_init(void);
void intext_deinit(void);
void int_to_string(int i, char *p);
void restore_my_texts(bool delete_yes);

void show_input_window(int index);
void show_level1_menu_window();
void show_help_window(int index);
void scroll_help_init(void);
void scroll_help_deinit(void);
void one_word_init(void);
void one_word_deinit(void);
void scroll_init(void);
void scroll_deinit(void);

