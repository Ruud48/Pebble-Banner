#define BUF200_SIZE 200

extern Window *banner_window; 
extern bool scroll_left;
extern GColor color_background;
extern GColor color_foreground;
extern uint8_t left_char_multiplier;
extern uint8_t up_char_multiplier;
extern uint8_t current_text_repeat;
extern GRect window_bounds;

void display_scrolling_text(GContext* ctx, char *text);
void scroll_init(void);
void scroll_deinit(void);