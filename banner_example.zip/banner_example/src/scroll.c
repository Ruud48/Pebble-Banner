
/*
 * Ver 1.0  4 July 2016
*/ 

#include <pebble.h>
#include "common.h"
	
#define FONT_RESOURCE_FILE RESOURCE_ID_BANNER_FONT	// Banner Font table stored as Resource Height = 15, Width = 10
#define FONT_CHAR_HEIGHT 15 									// Characters are 15 bit high and max. 10 bit wide, see font table
#define FONT_CHAR_WIDTH 10  									// Characters are 15 bit high and max. 10 bit wide, see font table
#define FONT_CHAR_FILLER 2										// space between the characters
#define FONT_SPACE_ROW 0x8000									// first font row of a space character for 16 bit font
	
#define LEFT_BANNER_HEIGHT_MULTIPLIER 11 			// 1 font bit = BANNER_HEIGHT_MULTIPLIER screen pixels
#define LEFT_BANNER_WIDTH_MULTIPLIER  11 			// 1 font bit = BANNER_WIDTH_MULTIPLIER screen pixels
	
#define UP_BANNER_HEIGHT_MULTIPLIER 9 				// 1 font bit = BANNER_HEIGHT_MULTIPLIER screen pixels
#define UP_BANNER_WIDTH_MULTIPLIER  9 				// 1 font bit = BANNER_WIDTH_MULTIPLIER screen pixels
#define UP_BANNER_RENDER_SIZE       9					// size of added triangles

#ifdef PBL_PLATFORM_CHALK
#define CHALK_BANNER_OFFSET 14
#else
#define CHALK_BANNER_OFFSET 0
#endif
	
Window *banner_window;

uint8_t left_char_multiplier = LEFT_BANNER_HEIGHT_MULTIPLIER;
uint8_t up_char_multiplier = UP_BANNER_HEIGHT_MULTIPLIER;
uint8_t text_index = 0;	
uint8_t current_text_repeat = 0;

static uint8_t start_font_row = 0;						// font row at screen pos. 0
static uint8_t banner_height_multiplier;
static uint8_t banner_width_multiplier;
static uint8_t banner_render_size;
static uint8_t banner_offset;


// tri-angles used for on the fly rendering of the UP banner characters only
GPath *bottom_left_pointer = NULL;
GPathInfo BOTTOMLEFT =  { .num_points = 3, .points = (GPoint [3]) { } };

GPath *top_left_pointer = NULL;
GPathInfo TOPLEFT =     { .num_points = 3, .points = (GPoint [3]) { } };

GPath *bottom_right_pointer = NULL;
GPathInfo BOTTOMRIGHT = { .num_points = 3, .points = (GPoint [3]) { } };

GPath *top_right_pointer = NULL;
GPathInfo TOPRIGHT =    { .num_points = 3, .points = (GPoint [3]) { } };


// *********************************************************************************************************
// Display very large scrolling text (eighter Horizontal (LEFT) or vertical (UP)) using it's own font table 
//
// MUST BE CALLED CONTINUOUSLY WITH A LITTLE (35 milliseconds) SPEED DELAY!!!
// 
//
void display_scrolling_text(GContext* ctx, char *text)
{
	int  current_screen_row, current_font_column, current_font_row, current_text_position, text_length, screen_size, char_multiplier;
	uint16_t dots, next_dots, previous_dots, font_column;
	bool add_spaces, font_bit_set;
	uint8_t c, pre_spaces, font_buffer[FONT_CHAR_WIDTH * 2];
	ResHandle rh;
	
	if (scroll_left == true)
	{
		screen_size = window_bounds.size.w;
		banner_height_multiplier = left_char_multiplier; // LEFT_BANNER_HEIGHT_MULTIPLIER;
		banner_width_multiplier	 = left_char_multiplier; // LEFT_BANNER_WIDTH_MULTIPLIER;
		banner_render_size       = left_char_multiplier; // LEFT_BANNER_RENDER_SIZE;
		char_multiplier = banner_height_multiplier;
		banner_offset = -CHALK_BANNER_OFFSET + (screen_size / 2) - ((FONT_CHAR_HEIGHT * (banner_height_multiplier - 2)) / 2);
	}
	else
	{
		screen_size = window_bounds.size.h;
		banner_height_multiplier = up_char_multiplier; // UP_BANNER_HEIGHT_MULTIPLIER;
		banner_width_multiplier	 = up_char_multiplier; // UP_BANNER_WIDTH_MULTIPLIER;
		banner_render_size       = up_char_multiplier; // UP_BANNER_RENDER_SIZE;
		char_multiplier = banner_width_multiplier;
		banner_offset = CHALK_BANNER_OFFSET + (screen_size / 2) - ((FONT_CHAR_HEIGHT * (banner_height_multiplier + 2)) / 2);
	}
	
	bottom_left_pointer->points  = (GPoint []) {{0, banner_render_size}, {banner_render_size, 0}, {banner_render_size, banner_render_size}};
	top_left_pointer->points     = (GPoint []) {{0, 0}, {0, banner_render_size}, {banner_render_size, banner_render_size}};
	bottom_right_pointer->points = (GPoint []) {{0, 0}, {banner_render_size, 0}, {banner_render_size, banner_render_size}};
	top_right_pointer->points    = (GPoint []) {{0, 0}, {0, banner_render_size}, {banner_render_size, 0}};

	pre_spaces = (screen_size / ((FONT_CHAR_WIDTH + FONT_CHAR_FILLER) * banner_width_multiplier)) + 1;
	current_text_position = text_index;
	current_font_row = start_font_row;
	dots = 0;
	text_length = strlen(text) + pre_spaces;	// simulate spaces in front of text
	add_spaces = false;
	
	graphics_context_set_stroke_color(ctx, color_foreground);
	graphics_context_set_fill_color(ctx, color_foreground);
	window_set_background_color(banner_window, color_background);
	rh = resource_get_handle(FONT_RESOURCE_FILE);	
	
	// Draw the whole pebble screen, then shift everything 1 font row
	for (current_screen_row = 0; current_screen_row < screen_size; current_screen_row += char_multiplier) 
	{
		previous_dots = dots;

		if ((current_font_row >= FONT_CHAR_WIDTH) || (current_text_position < pre_spaces) || (add_spaces == true))
			dots = FONT_SPACE_ROW;	// show spaces
		else
		{
			c = text[current_text_position - pre_spaces];
			if (c > 0x9f)
			{	
				if ((c == 0xc2) || (c == 0xc3))						// Handle UTF-8 Unicode characters U+0000 - U+00FF
					c = ((c & 0x3) << 6) + (text[1 + current_text_position - pre_spaces] & 0x3f);
				else
					c = '.';
			}	
				
			if (c < 0x20)
				c = '.';

			if (resource_load_byte_range(rh, (uint32_t)(c - 32) * (FONT_CHAR_WIDTH * 2), font_buffer, FONT_CHAR_WIDTH * 2) != (FONT_CHAR_WIDTH * 2))
				APP_LOG(APP_LOG_LEVEL_DEBUG, "ERROR in Font File");
		
			dots = (font_buffer[current_font_row * 2] << 8) + font_buffer[current_font_row * 2 + 1];
		}
		
		next_dots = 0;
		if (current_font_row < (FONT_CHAR_WIDTH - 1))
			next_dots = (font_buffer[(current_font_row + 1) * 2] << 8) + font_buffer[(current_font_row + 1) * 2 + 1];

		font_column = 0x01 << (FONT_CHAR_HEIGHT - 1);

 		for (current_font_column = 0; current_font_column < FONT_CHAR_HEIGHT; ++current_font_column)	
		{
			if (scroll_left == true)
				font_bit_set = dots & (font_column >> current_font_column);
			else
				font_bit_set = dots & (0x01 << current_font_column);
			
			if (font_bit_set == true)
			{
				if (scroll_left == true)
				{
					graphics_fill_circle(ctx, GPoint(current_screen_row, (banner_height_multiplier * current_font_column) + banner_offset), banner_render_size - 1 );
				}
				else
				{	
					graphics_fill_rect(ctx, GRect((banner_height_multiplier * current_font_column) + banner_offset, current_screen_row, banner_height_multiplier, banner_width_multiplier), 0, GCornerNone);

					if ((current_font_column < (FONT_CHAR_HEIGHT - 1)) && !(dots & (0x01 << (current_font_column + 1))) && (next_dots & (0x01 << (current_font_column + 1))))
					{	
						gpath_move_to(top_left_pointer, GPoint((banner_height_multiplier * (current_font_column)) + banner_offset + banner_render_size - 1, current_screen_row - 1));
						gpath_draw_filled(ctx, top_left_pointer);
					}	

					if ((current_font_column > 0) && !(dots & (0x01 << (current_font_column - 1))) && (next_dots & (0x01 << (current_font_column - 1))))
					{	
						gpath_move_to(bottom_left_pointer, GPoint((banner_height_multiplier * (current_font_column - 1)) + banner_offset + 0, current_screen_row - 1));
						gpath_draw_filled(ctx, bottom_left_pointer);
					}

					if ((current_font_column < (FONT_CHAR_HEIGHT - 1)) && !(dots & (0x01 << (current_font_column + 1))) && (previous_dots & (0x01 << (current_font_column + 1))))
					{	
						gpath_move_to(top_right_pointer, GPoint((banner_height_multiplier * (current_font_column - 1)) + banner_offset+ (banner_render_size * 2) - 1, current_screen_row));
						gpath_draw_filled(ctx, top_right_pointer);
					}	

					if ((current_font_column > 0) && !(dots & (0x01 << (current_font_column - 1))) && (previous_dots & (0x01 << (current_font_column - 1))))
					{	
						gpath_move_to(bottom_right_pointer, GPoint((banner_height_multiplier * (current_font_column)) + banner_offset - banner_render_size, current_screen_row - 0));
						gpath_draw_filled(ctx, bottom_right_pointer);
					}
				}	
			}
		}
			
		if ((dots & FONT_SPACE_ROW) == 0)														// end of character font ?
		{
			if (current_screen_row == 0)
				start_font_row += (FONT_CHAR_WIDTH - current_font_row - 1);
			current_font_row = FONT_CHAR_WIDTH - 1;										// skip not used font rows
		}
		
		if (++current_font_row >= FONT_CHAR_WIDTH + FONT_CHAR_FILLER)			// end of character ?
		{
			current_font_row = 0;
			if (current_text_position >= pre_spaces)
			{
				if ((text[current_text_position - pre_spaces] & 0xfc) == 0xc0)	// double byte ?	
					++current_text_position;
			}		
			if (++current_text_position >= text_length)								// last character ?
				add_spaces = true;
		}
	}
	
	if (++start_font_row >= FONT_CHAR_WIDTH + FONT_CHAR_FILLER)		// next character ?
	{
		start_font_row = 0;
		if ((text[text_index - pre_spaces] & 0xfc) == 0xc0)					// double byte ?
			++text_index;

		if (++text_index >= text_length)														// end of text ?
		{
			text_index = 0;
			++current_text_repeat;
		}	
	}
}

void scroll_init(void) 
{
	top_left_pointer = gpath_create(&TOPLEFT);
	top_right_pointer = gpath_create(&TOPRIGHT);
	bottom_left_pointer = gpath_create(&BOTTOMLEFT);
	bottom_right_pointer = gpath_create(&BOTTOMRIGHT);
}

void scroll_deinit(void) 
{
	gpath_destroy(top_left_pointer);
	gpath_destroy(top_right_pointer);
	gpath_destroy(bottom_left_pointer);
	gpath_destroy(bottom_right_pointer);
}
