/*
 * Banner-Example.c shows how to use Banner in your own program
 * 
 */

#include <pebble.h>
#include "common.h"
	
#define MESSAGE_DELAY 35				// sets scrolling speed
#define MY_TEXT "The Time is: "
	
bool scroll_left;								// scroll horizontal or vertical

GColor color_background;
GColor color_foreground;
static char buffer_200[BUF200_SIZE + 1];
GRect window_bounds;

static AppTimer *banner_timer_handle;		
static Layer *s_canvas_layer;


static void canvas_update_proc(Layer *this_layer, GContext *ctx) 
{
	color_foreground = COLOR_FALLBACK(GColorYellow, GColorWhite);
	color_background = COLOR_FALLBACK(GColorBlack, GColorBlack);
	
	if (current_text_repeat & 0x2)
	{
	  scroll_left = true;		
		if (current_text_repeat & 0x1)
			left_char_multiplier = 8;
	}	
	else
	{	
	  scroll_left = false;
		if (current_text_repeat & 0x1)
			up_char_multiplier = 6;
	}
	
  light_enable(true);															// Switch backlight on
	strcpy(buffer_200, MY_TEXT);
  clock_copy_time_string(buffer_200 + strlen(MY_TEXT), BUF200_SIZE - strlen(MY_TEXT));
  display_scrolling_text(ctx, buffer_200);
}

static void handle_banner_timer(void *data) 
{
  if (current_text_repeat < 5)	// Should we stop ?
	{	
		layer_mark_dirty(s_canvas_layer);
  	banner_timer_handle = app_timer_register(MESSAGE_DELAY, handle_banner_timer, NULL);
	}	
	else
	{
		light_enable(false);		
		window_stack_pop(false);
	}
}


static void main_window_load(Window *window) 
{
  Layer *window_layer = window_get_root_layer(window);
  window_bounds = layer_get_bounds(window_layer);

  s_canvas_layer = layer_create(GRect(0, 0, window_bounds.size.w, window_bounds.size.h));
  layer_add_child(window_layer, s_canvas_layer);

  layer_set_update_proc(s_canvas_layer, canvas_update_proc);
  handle_banner_timer(NULL);
}

static void main_window_unload(Window *window) 
{
//  app_timer_cancel(banner_timer_handle);
  layer_destroy(s_canvas_layer);
}

static void init(void) 
{
  banner_window = window_create();
  window_set_window_handlers(banner_window, (WindowHandlers) {
    .load = main_window_load,
    .unload = main_window_unload,
  });
  window_stack_push(banner_window, false);
}

static void deinit(void) 
{
  window_destroy(banner_window);
}

int main(void) 
{
  init();
	scroll_init();	
  app_event_loop();
	scroll_deinit();	
  deinit();
}
